<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}
include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $content = $_POST["content"];

    $stmt = $conn->prepare("INSERT INTO posts (title, content) VALUES (?, ?)");
    $stmt->bind_param("ss", $title, $content);
    $stmt->execute();
    $stmt->close();
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Create Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Create a New Post</h2>
    <form method="POST">
        <input type="text" name="title" placeholder="Post Title" required><br>
        <textarea name="content" placeholder="Post Content" rows="5" required></textarea><br>
        <button type="submit">Publish</button>
    </form>
    <a href="dashboard.php">← Back to Dashboard</a>
</body>
</html>