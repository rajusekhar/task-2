<?php
session_start();
include 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT title, content FROM posts WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($title, $content);
$stmt->fetch();
$stmt->close();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $newTitle = $_POST["title"];
    $newContent = $_POST["content"];

    $update = $conn->prepare("UPDATE posts SET title = ?, content = ? WHERE id = ?");
    $update->bind_param("ssi", $newTitle, $newContent, $id);
    $update->execute();
    $update->close();
    header("Location: dashboard.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Post</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Edit Post</h2>
    <form method="POST">
        <input type="text" name="title" value="<?= htmlspecialchars($title) ?>" required><br>
        <textarea name="content" rows="5" required><?= htmlspecialchars($content) ?></textarea><br>
        <button type="submit">Update</button>
    </form>
    <a href="dashboard.php">← Back to Dashboard</a>
</body>
</html>